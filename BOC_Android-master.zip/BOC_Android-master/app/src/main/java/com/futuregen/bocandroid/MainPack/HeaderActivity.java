package com.futuregen.bocandroid.MainPack;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.futuregen.bocandroid.R;

public class HeaderActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_header);
    }
}