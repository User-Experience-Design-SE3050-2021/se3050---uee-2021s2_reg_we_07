package com.futuregen.bocandroid.Exchange;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.futuregen.bocandroid.R;

public class ExchangeRates extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exchange_rates);
    }
}